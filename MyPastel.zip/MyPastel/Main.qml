import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15

ApplicationWindow {
    id: window
    width: 900
    height: 650
    visible: true
    title: "Pastel Girl"
    color: "#FFF0F5"

    property var dollState: {
        "body": "body",
        "hair": "hair_1",
        "eyes": "eyes_1",
        "brows": "brows_1",
        "mouth": "mouth_1",
        "jackets": "",
        "tops": "top_1",
        "bags": "",
        "hats": "",
        "bottoms": "bottom_1",
        "shoes": "shoe_1"
    }

    property string currentCategory: "hair"

    property var categories: {
        "body": { label: "Тело", items: ["body"] },
        "hair": { label: "Волосы", items: ["hair_1", "hair_2", "hair_3"] },
        "eyes": { label: "Глаза", items: ["eyes_1", "eyes_2", "eyes_3"] },
        "brows": { label: "Брови", items: ["brows_1", "brows_2", "brows_3"] },
        "mouth": { label: "Рот", items: ["mouth_1", "mouth_2", "mouth_3"] },
        "jackets": { label: "Куртки", items: ["jacket_1", "jacket_2"] },
        "tops": { label: "Топы", items: ["top_1", "top_2"] },
        "bags": { label: "Сумки", items: ["bag_1", "bag_2"] },
        "hats": { label: "Головные уборы", items: ["hat_1", "hat_2"] },
        "bottoms": { label: "Низ", items: ["bottom_1", "bottom_2"] },
        "shoes": { label: "Обувь", items: ["shoe_1", "shoe_2"] }
    }

    // ================================
    // ИНДИВИДУАЛЬНЫЕ НАСТРОЙКИ ДЛЯ КАЖДОГО ПРЕДМЕТА
    // ================================
    property var itemConfigs: {
        "body": {
            "body": { w: 250, h: 350, ox: 0, oy: 0 }
        },
        "hair": {
            "hair_1": { w: 300, h: 130, ox: 0, oy: -120 },
            "hair_2": { w: 300, h: 220, ox: 0, oy: -85 },
            "hair_3": { w: 300, h: 170, ox: 0, oy: -90 }
        },
        "eyes": {
            "eyes_1": { w: 90, h: 80, ox: 0, oy: -105 },
            "eyes_2": { w: 90, h: 80, ox: 0, oy: -107 },
            "eyes_3": { w: 90, h: 80, ox: 0, oy: -110 }
        },
        "brows": {
            "brows_1": { w: 90, h: 80, ox: 0, oy: -107 },
            "brows_2": { w: 90, h: 80, ox: 0, oy: -105 },
            "brows_3": { w: 90, h: 80, ox: 0, oy: -110 }
        },
        "mouth": {
            "mouth_1": { w: 100, h: 60, ox: 0, oy: -103 },
            "mouth_2": { w: 100, h: 60, ox: 0, oy: -100 },
            "mouth_3": { w: 100, h: 60, ox: 0, oy: -106 }
        },
        "jackets": {
            "jacket_1": { w: 100, h: 500, ox: 0, oy: -20 },
            "jacket_2": { w: 100, h: 500, ox: 0, oy: -20 }
        },
        "tops": {
            "top_1": { w: 64, h: 200, ox: 0, oy: -26 },
            "top_2": { w: 77, h: 200, ox: 0, oy: -39 }
        },
        "bags": {
            "bag_1": { w: 120, h: 150, ox: 15, oy: -8 },
            "bag_2": { w: 100, h: 150, ox: -20, oy: -10 }
        },
        "hats": {
            "hat_1": { w: 82, h: 150, ox: 22, oy: -160 },
            "hat_2": { w: 200, h: 150, ox: 0, oy: -185 }
        },
        "bottoms": {
            "bottom_1": { w: 119, h: 200, ox: 0, oy: 40 },
            "bottom_2": { w: 74, h: 200, ox: 0, oy: 77 }
        },
        "shoes": {
            "shoe_1": { w: 87, h: 100, ox: 0, oy: 160 },
            "shoe_2": { w: 64, h: 100, ox: 0, oy: 159 }
        }
    }

    // ================================
    // ФУНКЦИИ
    // ================================
    function getConfig(cat, item) {
        if (!item || item === "") return { w: 0, h: 0, ox: 0, oy: 0 }
        var config = itemConfigs[cat]
        if (!config) return { w: 0, h: 0, ox: 0, oy: 0 }
        return config[item] || { w: 0, h: 0, ox: 0, oy: 0 }
    }

    function getPath(cat, item) {
        if (!item || item === "") return ""
        return "file:///Users/romantsituk/QtProjects/MyPastel/" + cat + "/" + item + ".png"
    }

    function updateDoll() {
        var cfg

        cfg = getConfig("body", dollState.body)
        bodyL.source = getPath("body", dollState.body)
        bodyL.width = cfg.w; bodyL.height = cfg.h
        bodyL.anchors.horizontalCenterOffset = cfg.ox
        bodyL.anchors.verticalCenterOffset = cfg.oy

        cfg = getConfig("hair", dollState.hair)
        hairL.source = getPath("hair", dollState.hair)
        hairL.width = cfg.w; hairL.height = cfg.h
        hairL.anchors.horizontalCenterOffset = cfg.ox
        hairL.anchors.verticalCenterOffset = cfg.oy

        cfg = getConfig("eyes", dollState.eyes)
        eyesL.source = getPath("eyes", dollState.eyes)
        eyesL.width = cfg.w; eyesL.height = cfg.h
        eyesL.anchors.horizontalCenterOffset = cfg.ox
        eyesL.anchors.verticalCenterOffset = cfg.oy

        cfg = getConfig("brows", dollState.brows)
        browsL.source = getPath("brows", dollState.brows)
        browsL.width = cfg.w; browsL.height = cfg.h
        browsL.anchors.horizontalCenterOffset = cfg.ox
        browsL.anchors.verticalCenterOffset = cfg.oy

        cfg = getConfig("mouth", dollState.mouth)
        mouthL.source = getPath("mouth", dollState.mouth)
        mouthL.width = cfg.w; mouthL.height = cfg.h
        mouthL.anchors.horizontalCenterOffset = cfg.ox
        mouthL.anchors.verticalCenterOffset = cfg.oy

        cfg = getConfig("tops", dollState.tops)
        topL.source = getPath("tops", dollState.tops)
        topL.width = cfg.w; topL.height = cfg.h
        topL.anchors.horizontalCenterOffset = cfg.ox
        topL.anchors.verticalCenterOffset = cfg.oy

        cfg = getConfig("jackets", dollState.jackets)
        jacketL.source = getPath("jackets", dollState.jackets)
        jacketL.width = cfg.w; jacketL.height = cfg.h
        jacketL.anchors.horizontalCenterOffset = cfg.ox
        jacketL.anchors.verticalCenterOffset = cfg.oy

        cfg = getConfig("bottoms", dollState.bottoms)
        bottomL.source = getPath("bottoms", dollState.bottoms)
        bottomL.width = cfg.w; bottomL.height = cfg.h
        bottomL.anchors.horizontalCenterOffset = cfg.ox
        bottomL.anchors.verticalCenterOffset = cfg.oy

        cfg = getConfig("shoes", dollState.shoes)
        shoesL.source = getPath("shoes", dollState.shoes)
        shoesL.width = cfg.w; shoesL.height = cfg.h
        shoesL.anchors.horizontalCenterOffset = cfg.ox
        shoesL.anchors.verticalCenterOffset = cfg.oy

        cfg = getConfig("bags", dollState.bags)
        bagL.source = getPath("bags", dollState.bags)
        bagL.width = cfg.w; bagL.height = cfg.h
        bagL.anchors.horizontalCenterOffset = cfg.ox
        bagL.anchors.verticalCenterOffset = cfg.oy

        cfg = getConfig("hats", dollState.hats)
        hatL.source = getPath("hats", dollState.hats)
        hatL.width = cfg.w; hatL.height = cfg.h
        hatL.anchors.horizontalCenterOffset = cfg.ox
        hatL.anchors.verticalCenterOffset = cfg.oy
    }

    Timer {
        id: refreshTimer
        interval: 10
        onTriggered: updateDoll()
    }

    // ================================
    // КУКЛА
    // ================================
    Item {
        id: dollContainer
        anchors.centerIn: parent
        width: 600
        height: 700

        Image { id: bodyL; source: getPath("body", "body"); anchors.centerIn: parent; width: 250; height: 350; fillMode: Image.PreserveAspectFit; z: 0 }
        Image { id: hairL; source: getPath("hair", dollState.hair); anchors.centerIn: parent; width: 400; height: 400; fillMode: Image.PreserveAspectFit; z: 6 }
        Image { id: eyesL; source: getPath("eyes", dollState.eyes); anchors.centerIn: parent; width: 90; height: 80; fillMode: Image.PreserveAspectFit; z: 1 }
        Image { id: browsL; source: getPath("brows", dollState.brows); anchors.centerIn: parent; width: 90; height: 80; fillMode: Image.PreserveAspectFit; z: 7 }
        Image { id: mouthL; source: getPath("mouth", dollState.mouth); anchors.centerIn: parent; width: 100; height: 60; fillMode: Image.PreserveAspectFit; z: 8 }
        Image { id: topL; source: getPath("tops", dollState.top); anchors.centerIn: parent; width: 64; height: 200; fillMode: Image.PreserveAspectFit; z: 3 }
        Image { id: jacketL; source: getPath("jackets", dollState.jacket); anchors.centerIn: parent; width: 500; height: 500; fillMode: Image.PreserveAspectFit; z: 4 }
        Image { id: bottomL; source: getPath("bottoms", dollState.bottom); anchors.centerIn: parent; width: 119; height: 200; fillMode: Image.PreserveAspectFit; z: 2 }
        Image { id: shoesL; source: getPath("shoes", dollState.shoes); anchors.centerIn: parent; width: 85; height: 100; fillMode: Image.PreserveAspectFit; z: 10 }
        Image { id: bagL; source: getPath("bags", dollState.bag); anchors.centerIn: parent; width: 120; height: 150; fillMode: Image.PreserveAspectFit; z: 5 }
        Image { id: hatL; source: getPath("hats", dollState.hat); anchors.centerIn: parent; width: 200; height: 150; fillMode: Image.PreserveAspectFit; z: 9 }
    }

    // ================================
    // КНОПКИ КАТЕГОРИЙ
    // ================================
    Column {
        anchors.left: parent.left
        anchors.leftMargin: 10
        anchors.verticalCenter: parent.verticalCenter
        spacing: 5

        Repeater {
            model: Object.keys(categories)
            delegate: Button {
                text: categories[modelData].label
                width: 70
                height: 30
                background: Rectangle {
                    color: currentCategory === modelData ? "#FFB6C1" : "#FFE4E1"
                    radius: 5
                    border.color: currentCategory === modelData ? "#FF69B4" : "#FFB6C1"
                    border.width: 2
                }
                onClicked: {
                    currentCategory = modelData
                    itemsRepeater.model = categories[modelData].items
                }
            }
        }
    }

    // ================================
    // ПАНЕЛЬ ПРЕДМЕТОВ
    // ================================
    Rectangle {
        anchors.bottom: parent.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        height: 120
        color: "transparent"

        RowLayout {
            anchors.fill: parent
            anchors.margins: 10

            Button {
                text: "✕ Снять"
                height: 40
                width: 70
                background: Rectangle {
                    color: "#FFE4E1"
                    radius: 5
                    border.color: "#FFB6C1"
                    border.width: 2
                }
                onClicked: {
                    dollState[currentCategory] = ""
                    refreshTimer.start()
                }
            }

            ScrollView {
                Layout.fillWidth: true
                height: 100
                clip: true
                ScrollBar.horizontal.policy: ScrollBar.AlwaysOn

                Row {
                    spacing: 10
                    Repeater {
                        id: itemsRepeater
                        model: categories[currentCategory].items

                        delegate: Button {
                            width: 70
                            height: 90
                            background: Rectangle {
                                color: "white"
                                radius: 5
                                border.color: "#FFB6C1"
                                border.width: 2
                            }
                            contentItem: Column {
                                spacing: 2
                                Image {
                                    source: getPath(currentCategory, modelData)
                                    width: 50
                                    height: 50
                                    fillMode: Image.PreserveAspectFit
                                    anchors.horizontalCenter: parent.horizontalCenter
                                }
                                Text {
                                    text: modelData
                                    font.pixelSize: 8
                                    color: "#8B008B"
                                    anchors.horizontalCenter: parent.horizontalCenter
                                }
                            }
                            onClicked: {
                                dollState[currentCategory] = modelData
                                refreshTimer.start()
                            }
                        }
                    }
                }
            }
        }
    }

    // ================================
    // ЗАГОЛОВОК
    // ================================
    Text {
        anchors.top: parent.top
        anchors.topMargin: 10
        anchors.horizontalCenter: parent.horizontalCenter
        text: "🌸 Pastel Girl 🌸"
        font.pixelSize: 22
        font.bold: true
        color: "#8B008B"
    }

    Component.onCompleted: {
        itemsRepeater.model = categories[currentCategory].items
        updateDoll()
    }
}