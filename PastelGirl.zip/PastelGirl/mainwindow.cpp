#include "mainwindow.h"
#include <QLabel>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QScrollArea>
#include <QScrollBar>
#include <QFile>
#include <QApplication>
#include <QPixmap>
#include <QStandardPaths>
#include <QPainter>
#include <QBitmap>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    // Инициализация состояния куклы
    dollState["body"] = "body";
    dollState["hair"] = "hair_1";
    dollState["eyes"] = "eyes_1";
    dollState["brows"] = "brows_1";
    dollState["mouth"] = "mouth_1";
    dollState["jackets"] = "";
    dollState["tops"] = "top_1";
    dollState["bags"] = "";
    dollState["hats"] = "";
    dollState["bottoms"] = "bottom_1";
    dollState["shoes"] = "shoe_1";

    currentCategory = "hair";

    // Категории
    categories["body"] = {"Тело", {"body"}};
    categories["hair"] = {"Волосы", {"hair_1", "hair_2", "hair_3"}};
    categories["eyes"] = {"Глаза", {"eyes_1", "eyes_2", "eyes_3"}};
    categories["brows"] = {"Брови", {"brows_1", "brows_2", "brows_3"}};
    categories["mouth"] = {"Рот", {"mouth_1", "mouth_2", "mouth_3"}};
    categories["jackets"] = {"Куртки", {"jacket_1", "jacket_2"}};
    categories["tops"] = {"Топы", {"top_1", "top_2"}};
    categories["bags"] = {"Сумки", {"bag_1", "bag_2"}};
    categories["hats"] = {"Головные уборы", {"hat_1", "hat_2"}};
    categories["bottoms"] = {"Низ", {"bottom_1", "bottom_2"}};
    categories["shoes"] = {"Обувь", {"shoe_1", "shoe_2"}};

    // Конфигурации
    itemConfigs["body"]["body"] = {250, 350, 0, 0};
    itemConfigs["hair"]["hair_1"] = {300, 130, 0, -120};
    itemConfigs["hair"]["hair_2"] = {300, 220, 0, -85};
    itemConfigs["hair"]["hair_3"] = {300, 170, 0, -90};
    itemConfigs["eyes"]["eyes_1"] = {90, 80, 0, -105};
    itemConfigs["eyes"]["eyes_2"] = {90, 80, 0, -107};
    itemConfigs["eyes"]["eyes_3"] = {90, 80, 0, -110};
    itemConfigs["brows"]["brows_1"] = {90, 80, 0, -107};
    itemConfigs["brows"]["brows_2"] = {90, 80, 0, -105};
    itemConfigs["brows"]["brows_3"] = {90, 80, 0, -110};
    itemConfigs["mouth"]["mouth_1"] = {100, 60, 0, -103};
    itemConfigs["mouth"]["mouth_2"] = {100, 60, 0, -100};
    itemConfigs["mouth"]["mouth_3"] = {100, 60, 0, -106};
    itemConfigs["jackets"]["jacket_1"] = {100, 500, 0, -20};
    itemConfigs["jackets"]["jacket_2"] = {100, 500, 0, -20};
    itemConfigs["tops"]["top_1"] = {64, 200, 0, -26};
    itemConfigs["tops"]["top_2"] = {77, 200, 0, -39};
    itemConfigs["bags"]["bag_1"] = {120, 150, 15, -8};
    itemConfigs["bags"]["bag_2"] = {100, 150, -20, -10};
    itemConfigs["hats"]["hat_1"] = {82, 150, 22, -160};
    itemConfigs["hats"]["hat_2"] = {200, 150, 0, -185};
    itemConfigs["bottoms"]["bottom_1"] = {119, 200, 0, 40};
    itemConfigs["bottoms"]["bottom_2"] = {74, 200, 0, 77};
    itemConfigs["shoes"]["shoe_1"] = {87, 100, 0, 160};
    itemConfigs["shoes"]["shoe_2"] = {64, 100, 0, 159};

    setupUI();
    updateDoll();
}

MainWindow::~MainWindow()
{
}

void MainWindow::setupUI()
{
    setWindowTitle("Pastel Girl");
    setFixedSize(900, 650);
    setStyleSheet("background-color: #FFF0F5;");

    QWidget *centralWidget = new QWidget(this);
    setCentralWidget(centralWidget);

    QHBoxLayout *mainLayout = new QHBoxLayout(centralWidget);
    mainLayout->setContentsMargins(10, 10, 10, 10);
    mainLayout->setSpacing(10);

    // =========================================
    // Левая панель с категориями
    // =========================================
    QWidget *categoryPanel = new QWidget(this);
    categoryPanel->setFixedWidth(80);
    categoryLayout = new QVBoxLayout(categoryPanel);
    categoryLayout->setSpacing(5);
    categoryLayout->setAlignment(Qt::AlignCenter);

    QMapIterator<QString, CategoryData> it(categories);
    while (it.hasNext()) {
        it.next();
        const QString &key = it.key();
        const CategoryData &data = it.value();

        QPushButton *btn = new QPushButton(data.label, this);
        btn->setFixedSize(70, 30);
        btn->setCheckable(true);
        btn->setStyleSheet(
            "QPushButton {"
            "    background-color: #FFE4E1;"
            "    border: 2px solid #FFB6C1;"
            "    border-radius: 5px;"
            "    color: #8B008B;"
            "    font-size: 10px;"
            "}"
            "QPushButton:checked {"
            "    background-color: #FFB6C1;"
            "    border: 2px solid #FF69B4;"
            "}"
            "QPushButton:hover {"
            "    background-color: #FFD0D0;"
            "}"
            );

        connect(btn, &QPushButton::clicked, this, [this, key]() {
            selectCategory(key);
        });

        categoryLayout->addWidget(btn);
        categoryButtons[key] = btn;
    }

    categoryLayout->addStretch();
    mainLayout->addWidget(categoryPanel);

    // =========================================
    // Центральная область с куклой
    // =========================================
    QWidget *centerArea = new QWidget(this);
    QVBoxLayout *centerLayout = new QVBoxLayout(centerArea);
    centerLayout->setAlignment(Qt::AlignCenter);
    centerLayout->setSpacing(10);

    QLabel *titleLabel = new QLabel("🌸 Pastel Girl 🌸", this);
    titleLabel->setAlignment(Qt::AlignCenter);
    titleLabel->setStyleSheet(
        "font-size: 22px;"
        "font-weight: bold;"
        "color: #8B008B;"
        "background: transparent;"
        );
    centerLayout->addWidget(titleLabel);

    dollContainer = new QWidget(this);
    dollContainer->setFixedSize(600, 550);
    dollContainer->setStyleSheet("background: transparent;");

    QWidget *dollWidget = new QWidget(dollContainer);
    dollWidget->setFixedSize(600, 550);
    dollWidget->setStyleSheet("background: transparent;");

    // Создаем все части куклы как QLabel
    bodyLabel = new QLabel(dollWidget);
    hairLabel = new QLabel(dollWidget);
    eyesLabel = new QLabel(dollWidget);
    browsLabel = new QLabel(dollWidget);
    mouthLabel = new QLabel(dollWidget);
    topLabel = new QLabel(dollWidget);
    jacketLabel = new QLabel(dollWidget);
    bottomLabel = new QLabel(dollWidget);
    shoesLabel = new QLabel(dollWidget);
    bagLabel = new QLabel(dollWidget);
    hatLabel = new QLabel(dollWidget);

    // Настройка всех меток - ОТКЛЮЧАЕМ setScaledContents
    QList<QLabel*> labels = {bodyLabel, hairLabel, eyesLabel, browsLabel, mouthLabel,
                              topLabel, jacketLabel, bottomLabel, shoesLabel, bagLabel, hatLabel};
    for (QLabel *label : labels) {
        label->setScaledContents(false);  // Важно: отключаем автоматическое масштабирование
        label->setAlignment(Qt::AlignCenter);
        label->setStyleSheet("background: transparent;");
    }

    centerLayout->addWidget(dollContainer);
    mainLayout->addWidget(centerArea, 1);

    // =========================================
    // Нижняя панель с предметами
    // =========================================
    QWidget *bottomPanel = new QWidget(this);
    bottomPanel->setFixedHeight(120);
    bottomPanel->setStyleSheet("background: transparent;");
    QHBoxLayout *bottomLayout = new QHBoxLayout(bottomPanel);
    bottomLayout->setContentsMargins(10, 10, 10, 10);
    bottomLayout->setSpacing(10);

    QPushButton *removeBtn = new QPushButton("✕ Снять", this);
    removeBtn->setFixedSize(70, 40);
    removeBtn->setStyleSheet(
        "QPushButton {"
        "    background-color: #FFE4E1;"
        "    border: 2px solid #FFB6C1;"
        "    border-radius: 5px;"
        "    color: #8B008B;"
        "    font-size: 10px;"
        "}"
        "QPushButton:hover {"
        "    background-color: #FFD0D0;"
        "}"
        );
    connect(removeBtn, &QPushButton::clicked, this, &MainWindow::removeItem);
    bottomLayout->addWidget(removeBtn);

    itemsScrollArea = new QScrollArea(this);
    itemsScrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
    itemsScrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    itemsScrollArea->setStyleSheet(
        "QScrollArea {"
        "    background: transparent;"
        "    border: none;"
        "}"
        "QScrollBar:horizontal {"
        "    height: 10px;"
        "    background: #FFE4E1;"
        "    border-radius: 5px;"
        "}"
        "QScrollBar::handle:horizontal {"
        "    background: #FFB6C1;"
        "    border-radius: 5px;"
        "    min-width: 20px;"
        "}"
        "QScrollBar::handle:horizontal:hover {"
        "    background: #FF69B4;"
        "}"
        "QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {"
        "    border: none;"
        "    background: none;"
        "}"
        );
    itemsScrollArea->setFixedHeight(100);

    itemsPanel = new QWidget(this);
    itemsLayout = new QHBoxLayout(itemsPanel);
    itemsLayout->setContentsMargins(5, 5, 5, 5);
    itemsLayout->setSpacing(10);
    itemsLayout->setAlignment(Qt::AlignLeft);
    itemsPanel->setStyleSheet("background: transparent;");

    itemsScrollArea->setWidget(itemsPanel);
    itemsScrollArea->setWidgetResizable(true);
    bottomLayout->addWidget(itemsScrollArea);

    QVBoxLayout *rightLayout = new QVBoxLayout();
    rightLayout->addWidget(centerArea);
    rightLayout->addWidget(bottomPanel);
    mainLayout->addLayout(rightLayout, 1);

    selectCategory(currentCategory);
}

void MainWindow::selectCategory(const QString &category)
{
    currentCategory = category;

    QMapIterator<QString, QPushButton*> it(categoryButtons);
    while (it.hasNext()) {
        it.next();
        it.value()->setChecked(it.key() == category);
    }

    clearLayout(itemsLayout);

    const CategoryData &catData = categories[category];
    const QStringList &items = catData.items;

    for (const QString &item : items) {
        QPushButton *btn = new QPushButton(itemsPanel);
        btn->setFixedSize(70, 90);
        btn->setStyleSheet(
            "QPushButton {"
            "    background-color: white;"
            "    border: 2px solid #FFB6C1;"
            "    border-radius: 5px;"
            "}"
            "QPushButton:hover {"
            "    border-color: #FF69B4;"
            "    background-color: #FFF0F5;"
            "}"
            );

        QVBoxLayout *btnLayout = new QVBoxLayout(btn);
        btnLayout->setSpacing(2);
        btnLayout->setContentsMargins(5, 5, 5, 5);
        btnLayout->setAlignment(Qt::AlignCenter);

        QLabel *iconLabel = new QLabel(btn);
        iconLabel->setFixedSize(50, 50);
        iconLabel->setScaledContents(false);  // Отключаем масштабирование
        iconLabel->setStyleSheet("background: transparent;");
        iconLabel->setAlignment(Qt::AlignCenter);

        QString path = getPath(category, item);
        if (QFile::exists(path)) {
            QPixmap pixmap(path);
            if (!pixmap.isNull()) {
                // Масштабируем с сохранением пропорций и качеством
                QPixmap scaled = pixmap.scaled(50, 50, Qt::KeepAspectRatio, Qt::SmoothTransformation);
                iconLabel->setPixmap(scaled);
            }
        }
        btnLayout->addWidget(iconLabel);

        QLabel *nameLabel = new QLabel(item, btn);
        nameLabel->setAlignment(Qt::AlignCenter);
        nameLabel->setStyleSheet("font-size: 8px; color: #8B008B; background: transparent;");
        btnLayout->addWidget(nameLabel);

        connect(btn, &QPushButton::clicked, this, [this, category, item]() {
            selectItem(category, item);
        });

        itemsLayout->addWidget(btn);
    }

    itemsLayout->addStretch();
}

void MainWindow::clearLayout(QLayout *layout)
{
    QLayoutItem *child;
    while ((child = layout->takeAt(0)) != nullptr) {
        if (child->widget()) {
            delete child->widget();
        }
        delete child;
    }
}

void MainWindow::selectItem(const QString &category, const QString &item)
{
    dollState[category] = item;
    updateDoll();
}

void MainWindow::removeItem()
{
    dollState[currentCategory] = "";
    updateDoll();
}

void MainWindow::updateDoll()
{
    QList<QLabel*> labels = {bodyLabel, hairLabel, eyesLabel, browsLabel, mouthLabel,
                              topLabel, jacketLabel, bottomLabel, shoesLabel, bagLabel, hatLabel};
    QStringList keys = {"body", "hair", "eyes", "brows", "mouth", "tops",
                        "jackets", "bottoms", "shoes", "bags", "hats"};

    for (int i = 0; i < labels.size(); ++i) {
        QLabel *label = labels[i];
        const QString &key = keys[i];
        const QString &item = dollState[key];

        if (item.isEmpty()) {
            label->clear();
            label->setVisible(false);
            continue;
        }

        label->setVisible(true);
        ItemConfig config = getConfig(key, item);
        QString path = getPath(key, item);

        if (QFile::exists(path)) {
            QPixmap pixmap(path);
            if (!pixmap.isNull()) {
                // Масштабируем с сохранением пропорций и максимальным качеством
                QPixmap scaled = pixmap.scaled(config.width, config.height,
                                               Qt::KeepAspectRatio,
                                               Qt::SmoothTransformation);

                // Если изображение меньше нужного размера, не растягиваем
                if (scaled.width() < config.width || scaled.height() < config.height) {
                    // Создаем пустое изображение нужного размера и центрируем
                    QPixmap centered(config.width, config.height);
                    centered.fill(Qt::transparent);
                    QPainter painter(&centered);
                    painter.drawPixmap((config.width - scaled.width()) / 2,
                                       (config.height - scaled.height()) / 2,
                                       scaled);
                    painter.end();
                    label->setPixmap(centered);
                } else {
                    label->setPixmap(scaled);
                }

                label->setFixedSize(config.width, config.height);

                int parentWidth = dollContainer->width();
                int parentHeight = dollContainer->height();

                int x = (parentWidth - config.width) / 2 + config.offsetX;
                int y = (parentHeight - config.height) / 2 + config.offsetY;

                label->move(x, y);
            }
        }
    }
}

QString MainWindow::getPath(const QString &category, const QString &item) const
{
    if (item.isEmpty()) return QString();

    QStringList paths;
    paths << "/Users/romantsituk/QtProjects/MyPastel/" + category + "/" + item + ".png";
    paths << QApplication::applicationDirPath() + "/../Resources/" + category + "/" + item + ".png";
    paths << QApplication::applicationDirPath() + "/" + category + "/" + item + ".png";
    paths << QApplication::applicationDirPath() + "/../" + category + "/" + item + ".png";

    QString home = QStandardPaths::writableLocation(QStandardPaths::HomeLocation);
    paths << home + "/QtProjects/MyPastel/" + category + "/" + item + ".png";

    for (const QString &path : paths) {
        if (QFile::exists(path)) {
            return path;
        }
    }

    return paths.first();
}

ItemConfig MainWindow::getConfig(const QString &category, const QString &item) const
{
    if (item.isEmpty() || !itemConfigs.contains(category)) {
        return {0, 0, 0, 0};
    }

    const QMap<QString, ItemConfig> &categoryMap = itemConfigs[category];
    if (!categoryMap.contains(item)) {
        return {0, 0, 0, 0};
    }

    return categoryMap[item];
}