QT += widgets

CONFIG += c++17
CONFIG += warn_off

# Для macOS
macx {
    QMAKE_CXXFLAGS += -Wno-implicit-function-declaration
    QMAKE_CXXFLAGS += -Wno-deprecated-declarations
    QMAKE_CXXFLAGS += -Wno-unused-parameter
    QMAKE_CXXFLAGS += -Wno-clazy-qstring-arg
    QMAKE_CXXFLAGS += -Wno-clazy-detaching-temporary
}

TARGET = MyPastel
TEMPLATE = app

DEFINES += QT_DEPRECATED_WARNINGS

SOURCES += \
    main.cpp \
    mainwindow.cpp

HEADERS += \
    mainwindow.h

# Default rules for deployment.
qnx: target.path = /tmp/$${TARGET}/bin
else: unix:!android: target.path = /opt/$${TARGET}/bin
!isEmpty(target.path): INSTALLS += target

# Для macOS
macx {
    ICON = app.icns
    QMAKE_INFO_PLIST = Info.plist
}