#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMap>
#include <QString>
#include <QList>

QT_BEGIN_NAMESPACE
class QLabel;
class QPushButton;
class QScrollArea;
class QVBoxLayout;
class QHBoxLayout;
class QWidget;
class QGridLayout;
QT_END_NAMESPACE

struct ItemConfig {
    int width;
    int height;
    int offsetX;
    int offsetY;
};

struct CategoryData {
    QString label;
    QStringList items;
};

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void selectCategory(const QString &category);
    void selectItem(const QString &category, const QString &item);
    void removeItem();

private:
    void setupUI();
    void updateDoll();
    QString getPath(const QString &category, const QString &item) const;
    ItemConfig getConfig(const QString &category, const QString &item) const;
    void clearLayout(QLayout *layout);

    // Данные куклы
    QMap<QString, QString> dollState;
    QString currentCategory;

    // Категории и их элементы
    QMap<QString, CategoryData> categories;
    QMap<QString, QMap<QString, ItemConfig>> itemConfigs;

    // Виджеты куклы
    QLabel *bodyLabel;
    QLabel *hairLabel;
    QLabel *eyesLabel;
    QLabel *browsLabel;
    QLabel *mouthLabel;
    QLabel *topLabel;
    QLabel *jacketLabel;
    QLabel *bottomLabel;
    QLabel *shoesLabel;
    QLabel *bagLabel;
    QLabel *hatLabel;

    // Контейнер для куклы
    QWidget *dollContainer;

    // Кнопки категорий
    QMap<QString, QPushButton*> categoryButtons;
    QVBoxLayout *categoryLayout;

    // Панель предметов
    QScrollArea *itemsScrollArea;
    QWidget *itemsPanel;
    QHBoxLayout *itemsLayout;
};

#endif // MAINWINDOW_H